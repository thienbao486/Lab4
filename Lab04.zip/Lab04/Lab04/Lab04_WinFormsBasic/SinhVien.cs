using System;

namespace Lab04_WinFormsBasic
{
    // Lop mo hinh SinhVien, chuan bi cho cac bai lab tiep theo.
    public class SinhVien
    {
        public string MaSV { get; set; }
        public string HoTen { get; set; }
        public DateTime NgaySinh { get; set; }
        public string GioiTinh { get; set; }
        public string Khoa { get; set; }
        public string SoThich { get; set; }
        public string DuongDanAnh { get; set; }
    }
}

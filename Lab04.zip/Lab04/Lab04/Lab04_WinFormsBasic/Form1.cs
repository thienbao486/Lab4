using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Lab04_WinFormsBasic
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Bai 2: Nap khoa va thiet lap trang thai mac dinh khi mo Form.
        private void Form1_Load(object sender, EventArgs e)
        {
            cboKhoa.Items.Clear();
            cboKhoa.Items.Add("Công nghệ thông tin");
            cboKhoa.Items.Add("Công nghệ kỹ thuật ô tô");
            cboKhoa.Items.Add("Kinh tế");
            cboKhoa.DropDownStyle = ComboBoxStyle.DropDownList;

            if (cboKhoa.Items.Count > 0)
                cboKhoa.SelectedIndex = 0;

            radNam.Checked = true;
            dtpNgaySinh.Format = DateTimePickerFormat.Short;
            picAnh.SizeMode = PictureBoxSizeMode.Zoom;
            CapNhatTuoi();
        }

        // Bai 1: Hien thi thong tin sinh vien.
        private void btnHienThi_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaSV.Text))
            {
                MessageBox.Show("Vui lòng nhập mã sinh viên!", "Thiếu thông tin",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaSV.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Vui lòng nhập họ và tên!", "Thiếu thông tin",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHoTen.Focus();
                return;
            }

            string gioiTinh = radNam.Checked ? "Nam" : "Nữ";
            string thongTin = string.Format(
                "Mã: {0}\nHọ tên: {1}\nNgày sinh: {2:dd/MM/yyyy}\nTuổi: {3}\nKhoa: {4}\nGiới tính: {5}\nSở thích: {6}\nẢnh: {7}",
                txtMaSV.Text.Trim(),
                txtHoTen.Text.Trim(),
                dtpNgaySinh.Value,
                TinhTuoi(dtpNgaySinh.Value),
                cboKhoa.Text,
                gioiTinh,
                lblSoThich.Text,
                string.IsNullOrWhiteSpace(txtDuongDanAnh.Text) ? "Chưa chọn" : txtDuongDanAnh.Text);

            MessageBox.Show(thongTin, "Thông tin sinh viên",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Bai 3: Tinh tuoi dung, co kiem tra da qua sinh nhat trong nam chua.
        private int TinhTuoi(DateTime ngaySinh)
        {
            int tuoi = DateTime.Today.Year - ngaySinh.Year;
            if (ngaySinh.Date > DateTime.Today.AddYears(-tuoi))
                tuoi--;
            return tuoi;
        }

        private void dtpNgaySinh_ValueChanged(object sender, EventArgs e)
        {
            CapNhatTuoi();
        }

        private void CapNhatTuoi()
        {
            if (lblTuoi != null && dtpNgaySinh != null)
                lblTuoi.Text = "Tuổi: " + TinhTuoi(dtpNgaySinh.Value);
        }

        // Bai 4: Tong hop cac CheckBox so thich duoc chon.
        private void btnSoThich_Click(object sender, EventArgs e)
        {
            List<string> ds = new List<string>();
            if (chkDocSach.Checked) ds.Add("Đọc sách");
            if (chkTheThao.Checked) ds.Add("Thể thao");
            if (chkLapTrinh.Checked) ds.Add("Lập trình");

            lblSoThich.Text = ds.Count == 0 ? "Chưa chọn" : string.Join(", ", ds);
        }

        // Bai 5: Chon anh va hien thi trong PictureBox.
        private void btnChonAnh_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "Chọn ảnh đại diện";
                dlg.Filter = "Image files|*.jpg;*.jpeg;*.png;*.bmp";
                dlg.Multiselect = false;

                if (dlg.ShowDialog() != DialogResult.OK)
                    return;

                try
                {
                    // Tao ban sao de khong khoa tep anh sau khi mo.
                    using (Image anhTam = Image.FromFile(dlg.FileName))
                    {
                        Image anhCu = picAnh.Image;
                        picAnh.Image = new Bitmap(anhTam);
                        if (anhCu != null)
                            anhCu.Dispose();
                    }

                    picAnh.SizeMode = PictureBoxSizeMode.Zoom;
                    txtDuongDanAnh.Text = dlg.FileName;
                }
                catch (Exception)
                {
                    MessageBox.Show("Không thể mở tệp ảnh này. Vui lòng chọn ảnh JPG, PNG hoặc BMP.",
                        "Lỗi ảnh", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}

namespace Lab04_WinFormsBasic
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblTieuDe, lblMaSV, lblHoTen, lblNgaySinh, lblGioiTinh, lblKhoa, lblTuoi, lblSoThich, lblAnh;
        private System.Windows.Forms.TextBox txtMaSV, txtHoTen, txtDuongDanAnh;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.RadioButton radNam, radNu;
        private System.Windows.Forms.ComboBox cboKhoa;
        private System.Windows.Forms.Button btnHienThi, btnSoThich, btnChonAnh;
        private System.Windows.Forms.CheckBox chkDocSach, chkTheThao, chkLapTrinh;
        private System.Windows.Forms.PictureBox picAnh;
        private System.Windows.Forms.GroupBox grpThongTin, grpSoThich, grpAnh;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.grpThongTin = new System.Windows.Forms.GroupBox();
            this.lblMaSV = new System.Windows.Forms.Label();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.lblGioiTinh = new System.Windows.Forms.Label();
            this.lblKhoa = new System.Windows.Forms.Label();
            this.lblTuoi = new System.Windows.Forms.Label();
            this.txtMaSV = new System.Windows.Forms.TextBox();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.radNam = new System.Windows.Forms.RadioButton();
            this.radNu = new System.Windows.Forms.RadioButton();
            this.cboKhoa = new System.Windows.Forms.ComboBox();
            this.grpSoThich = new System.Windows.Forms.GroupBox();
            this.chkDocSach = new System.Windows.Forms.CheckBox();
            this.chkTheThao = new System.Windows.Forms.CheckBox();
            this.chkLapTrinh = new System.Windows.Forms.CheckBox();
            this.btnSoThich = new System.Windows.Forms.Button();
            this.lblSoThich = new System.Windows.Forms.Label();
            this.grpAnh = new System.Windows.Forms.GroupBox();
            this.picAnh = new System.Windows.Forms.PictureBox();
            this.btnChonAnh = new System.Windows.Forms.Button();
            this.txtDuongDanAnh = new System.Windows.Forms.TextBox();
            this.lblAnh = new System.Windows.Forms.Label();
            this.btnHienThi = new System.Windows.Forms.Button();
            this.grpThongTin.SuspendLayout();
            this.grpSoThich.SuspendLayout();
            this.grpAnh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAnh)).BeginInit();
            this.SuspendLayout();
            //
            // lblTieuDe
            //
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(255, 14);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(242, 25);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "THÔNG TIN SINH VIÊN";
            //
            // grpThongTin
            //
            this.grpThongTin.Controls.Add(this.lblMaSV);
            this.grpThongTin.Controls.Add(this.lblHoTen);
            this.grpThongTin.Controls.Add(this.lblNgaySinh);
            this.grpThongTin.Controls.Add(this.lblGioiTinh);
            this.grpThongTin.Controls.Add(this.lblKhoa);
            this.grpThongTin.Controls.Add(this.lblTuoi);
            this.grpThongTin.Controls.Add(this.txtMaSV);
            this.grpThongTin.Controls.Add(this.txtHoTen);
            this.grpThongTin.Controls.Add(this.dtpNgaySinh);
            this.grpThongTin.Controls.Add(this.radNam);
            this.grpThongTin.Controls.Add(this.radNu);
            this.grpThongTin.Controls.Add(this.cboKhoa);
            this.grpThongTin.Location = new System.Drawing.Point(18, 48);
            this.grpThongTin.Name = "grpThongTin";
            this.grpThongTin.Size = new System.Drawing.Size(425, 250);
            this.grpThongTin.TabIndex = 1;
            this.grpThongTin.TabStop = false;
            this.grpThongTin.Text = "Bài 1-3: Thông tin sinh viên";
            //
            // labels and inputs
            //
            this.lblMaSV.AutoSize = true; this.lblMaSV.Location = new System.Drawing.Point(18, 32); this.lblMaSV.Name = "lblMaSV"; this.lblMaSV.Text = "Mã sinh viên";
            this.lblHoTen.AutoSize = true; this.lblHoTen.Location = new System.Drawing.Point(18, 70); this.lblHoTen.Name = "lblHoTen"; this.lblHoTen.Text = "Họ và tên";
            this.lblNgaySinh.AutoSize = true; this.lblNgaySinh.Location = new System.Drawing.Point(18, 108); this.lblNgaySinh.Name = "lblNgaySinh"; this.lblNgaySinh.Text = "Ngày sinh";
            this.lblGioiTinh.AutoSize = true; this.lblGioiTinh.Location = new System.Drawing.Point(18, 146); this.lblGioiTinh.Name = "lblGioiTinh"; this.lblGioiTinh.Text = "Giới tính";
            this.lblKhoa.AutoSize = true; this.lblKhoa.Location = new System.Drawing.Point(18, 184); this.lblKhoa.Name = "lblKhoa"; this.lblKhoa.Text = "Khoa";
            this.lblTuoi.AutoSize = true; this.lblTuoi.Location = new System.Drawing.Point(18, 220); this.lblTuoi.Name = "lblTuoi"; this.lblTuoi.Text = "Tuổi: ";
            this.txtMaSV.Location = new System.Drawing.Point(135, 29); this.txtMaSV.Name = "txtMaSV"; this.txtMaSV.Size = new System.Drawing.Size(260, 20);
            this.txtHoTen.Location = new System.Drawing.Point(135, 67); this.txtHoTen.Name = "txtHoTen"; this.txtHoTen.Size = new System.Drawing.Size(260, 20);
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short; this.dtpNgaySinh.Location = new System.Drawing.Point(135, 105); this.dtpNgaySinh.Name = "dtpNgaySinh"; this.dtpNgaySinh.Size = new System.Drawing.Size(260, 20); this.dtpNgaySinh.ValueChanged += new System.EventHandler(this.dtpNgaySinh_ValueChanged);
            this.radNam.AutoSize = true; this.radNam.Location = new System.Drawing.Point(135, 144); this.radNam.Name = "radNam"; this.radNam.Text = "Nam"; this.radNam.Checked = true;
            this.radNu.AutoSize = true; this.radNu.Location = new System.Drawing.Point(230, 144); this.radNu.Name = "radNu"; this.radNu.Text = "Nữ";
            this.cboKhoa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList; this.cboKhoa.Location = new System.Drawing.Point(135, 181); this.cboKhoa.Name = "cboKhoa"; this.cboKhoa.Size = new System.Drawing.Size(260, 21);
            //
            // grpSoThich
            //
            this.grpSoThich.Controls.Add(this.chkDocSach);
            this.grpSoThich.Controls.Add(this.chkTheThao);
            this.grpSoThich.Controls.Add(this.chkLapTrinh);
            this.grpSoThich.Controls.Add(this.btnSoThich);
            this.grpSoThich.Controls.Add(this.lblSoThich);
            this.grpSoThich.Location = new System.Drawing.Point(18, 310);
            this.grpSoThich.Name = "grpSoThich";
            this.grpSoThich.Size = new System.Drawing.Size(425, 142);
            this.grpSoThich.TabIndex = 2;
            this.grpSoThich.TabStop = false;
            this.grpSoThich.Text = "Bài 4: Sở thích";
            this.chkDocSach.AutoSize = true; this.chkDocSach.Location = new System.Drawing.Point(20, 29); this.chkDocSach.Name = "chkDocSach"; this.chkDocSach.Text = "Đọc sách";
            this.chkTheThao.AutoSize = true; this.chkTheThao.Location = new System.Drawing.Point(135, 29); this.chkTheThao.Name = "chkTheThao"; this.chkTheThao.Text = "Thể thao";
            this.chkLapTrinh.AutoSize = true; this.chkLapTrinh.Location = new System.Drawing.Point(250, 29); this.chkLapTrinh.Name = "chkLapTrinh"; this.chkLapTrinh.Text = "Lập trình";
            this.btnSoThich.Location = new System.Drawing.Point(20, 61); this.btnSoThich.Name = "btnSoThich"; this.btnSoThich.Size = new System.Drawing.Size(120, 28); this.btnSoThich.Text = "Hiện sở thích"; this.btnSoThich.Click += new System.EventHandler(this.btnSoThich_Click);
            this.lblSoThich.AutoSize = false; this.lblSoThich.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle; this.lblSoThich.Location = new System.Drawing.Point(20, 101); this.lblSoThich.Name = "lblSoThich"; this.lblSoThich.Size = new System.Drawing.Size(380, 25); this.lblSoThich.Text = "Chưa chọn";
            //
            // grpAnh
            //
            this.grpAnh.Controls.Add(this.picAnh);
            this.grpAnh.Controls.Add(this.btnChonAnh);
            this.grpAnh.Controls.Add(this.txtDuongDanAnh);
            this.grpAnh.Controls.Add(this.lblAnh);
            this.grpAnh.Location = new System.Drawing.Point(460, 48);
            this.grpAnh.Name = "grpAnh";
            this.grpAnh.Size = new System.Drawing.Size(290, 250);
            this.grpAnh.TabIndex = 3;
            this.grpAnh.TabStop = false;
            this.grpAnh.Text = "Bài 5: Ảnh đại diện";
            this.picAnh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picAnh.Location = new System.Drawing.Point(55, 27);
            this.picAnh.Name = "picAnh";
            this.picAnh.Size = new System.Drawing.Size(180, 150);
            this.picAnh.TabStop = false;
            this.picAnh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lblAnh.AutoSize = true; this.lblAnh.Location = new System.Drawing.Point(14, 190); this.lblAnh.Name = "lblAnh"; this.lblAnh.Text = "Đường dẫn:";
            this.txtDuongDanAnh.Location = new System.Drawing.Point(14, 210); this.txtDuongDanAnh.Name = "txtDuongDanAnh"; this.txtDuongDanAnh.Size = new System.Drawing.Size(260, 20); this.txtDuongDanAnh.ReadOnly = true;
            this.btnChonAnh.Location = new System.Drawing.Point(85, 177); this.btnChonAnh.Name = "btnChonAnh"; this.btnChonAnh.Size = new System.Drawing.Size(120, 27); this.btnChonAnh.Text = "Chọn ảnh"; this.btnChonAnh.Click += new System.EventHandler(this.btnChonAnh_Click);
            //
            // btnHienThi
            //
            this.btnHienThi.Location = new System.Drawing.Point(500, 330);
            this.btnHienThi.Name = "btnHienThi";
            this.btnHienThi.Size = new System.Drawing.Size(210, 45);
            this.btnHienThi.TabIndex = 4;
            this.btnHienThi.Text = "Hiển thị thông tin sinh viên";
            this.btnHienThi.UseVisualStyleBackColor = true;
            this.btnHienThi.Click += new System.EventHandler(this.btnHienThi_Click);
            //
            // Form1
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(770, 475);
            this.Controls.Add(this.btnHienThi);
            this.Controls.Add(this.grpAnh);
            this.Controls.Add(this.grpSoThich);
            this.Controls.Add(this.grpThongTin);
            this.Controls.Add(this.lblTieuDe);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lab 4 - WinForms cơ bản";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpThongTin.ResumeLayout(false);
            this.grpThongTin.PerformLayout();
            this.grpSoThich.ResumeLayout(false);
            this.grpSoThich.PerformLayout();
            this.grpAnh.ResumeLayout(false);
            this.grpAnh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAnh)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}

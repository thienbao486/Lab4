LAB 04 - WINFORMS CO BAN - BAI 1 DEN BAI 5
============================================

Noi dung da lam:
1. Form thong tin sinh vien: ma SV, ho ten, ngay sinh, gioi tinh, khoa, nut hien thi.
2. Nap danh sach khoa khi Form Load, chon khoa dau tien va mac dinh gioi tinh Nam.
3. Tinh tuoi tu DateTimePicker va cap nhat khi ngay sinh thay doi.
4. Chon so thich bang CheckBox va hien thi danh sach da chon.
5. Chon anh bang OpenFileDialog va hien thi trong PictureBox o che do Zoom.

Cach mo:
1. Giai nen ZIP.
2. Mo Visual Studio 2022.
3. Chon Open a project or solution.
4. Mo Lab04_WinFormsBasic.sln.
5. Neu duoc yeu cau .NET Framework 4.8 Developer/Targeting Pack, cai dat pack.
6. Nhan Ctrl+Shift+B de Build, sau do F5 de chay.
7. Mo Form1.cs va chon View Designer de xem/chinh giao dien.

Ten control da duoc gan san va su kien duoc noi san trong Designer.
Khong can tao lai su kien bang tay.
Luu y: Form1.Designer.cs la file giao dien sinh boi Windows Forms; nen chinh giao dien qua Designer.
